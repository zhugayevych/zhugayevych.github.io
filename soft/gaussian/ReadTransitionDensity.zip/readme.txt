
1) If needed, generate public and private keys for SSH connection to nano (if you use puttygen.exe convert the private key to OpenSSH format).

2) Copy readdump somewhere to your nano directory (e.g. "/bin").

3) If needed, install Python and IPython. For Windows I recommend Anaconda from http://continuum.io/downloads. Also you will need "paramiko" module: run "conda install paramiko" from command line. If LANL blocks conda then try this: 1) copy .condarc to the root of your home directory; 2) if doesn.t work - send your IP to AskIT; 3) if doesn.t work - download paramiko and dependencies from repository and run "conda install <module_file_name>".

4) Run IPython by one of these methods:
 a) for Windows run the provided here LaunchIPy.bat (remove "no-browser" option if a correct browser is launched),
 b) from Anaconda launcher,
 c) by running "ipython notebook" from command line.

5) If not done automatically, open a browser and go to "localhost:8888/tree".

6) Open ReadTransitionDensity.ipynb in IPython.

7) You may explore also ReadWrite.ipynb.
