ren %1 %~n1.bak%~x1
C:\Sys\ffmpeg\bin\ffmpeg.exe -ss 310 -t 158 -i %~n1.bak%~x1 %~n1%~x1