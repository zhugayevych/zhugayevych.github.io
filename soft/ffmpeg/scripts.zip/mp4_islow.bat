ren %1 %~n1.bak%~x1
C:\Sys\ffmpeg\bin\ffmpeg.exe -i %~n1.bak%~x1 -vf yadif -preset veryslow %~n1.mp4