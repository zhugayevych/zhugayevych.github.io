C:\Sys\ffmpeg\bin\ffmpeg.exe -i %1>>_tmp_ffmpeg.log 2>&1
