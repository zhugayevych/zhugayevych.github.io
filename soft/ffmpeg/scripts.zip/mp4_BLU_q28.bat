ren %1 %~n1.bak%~x1
C:\Sys\ffmpeg\bin\ffmpeg.exe -i %~n1.bak%~x1 -vf mpdecimate -crf 28 -preset veryslow %~n1.mp4