ren %1 %~n1.bak%~x1
C:\Sys\ffmpeg\bin\ffmpeg.exe -i %~n1.bak%~x1 -vf yadif,scale=iw/2:ih/2 -preset veryslow %~n1.mp4