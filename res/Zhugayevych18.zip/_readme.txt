
Atomic coordinates for all polymorphs optimized by vdW-DF2 DFT method are listed in this archive.

Translations vectors are labeled by "Tv".

Layer group is given in the comment line of each file after "SG=".

For other data discussed in the article please contact the authors.
