Comparison of density fitting basis sets for methane:

       N  Nmonom  maxL  dNe3   dNe4   file
Auto   79   90     F    .065   .066    20
W06    93  109     G   -.285  -.282    21
SVP    69   75     F   -.016  -.014    22
TZVP   74   80     F    .057   .059    23
DGA1   47   50     D   -.133  -.129    24

Here N is number of functions, dNeX is deficit in total number of electrons when rho is cut at 1e-X
