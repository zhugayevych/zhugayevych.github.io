

                     SUMMARY OF  PM7 CALCULATION, Site No: 7031

                                                       MOPAC2016 (Version: 20.288W)
                                                       Tue Oct 27 23:28:27 2020
                                                       No. of days remaining = 353

           Empirical Formula: C6 H6  =    12 atoms

 T=99D PM7 GNORM=0
 Geometry optimization



     GEOMETRY OPTIMISED USING EIGENVECTOR FOLLOWING (EF).     
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =         22.95651 KCAL/MOL =      96.05002 KJ/MOL
          TOTAL ENERGY            =       -817.56195 EV
          ELECTRONIC ENERGY       =      -3251.15844 EV
          CORE-CORE REPULSION     =       2433.59649 EV
          GRADIENT NORM           =          0.00613 = 0.00177 PER ATOM
          DIPOLE                  =          0.00002 DEBYE    POINT GROUP:       D6h 
          NO. OF FILLED LEVELS    =         15
          IONIZATION POTENTIAL    =          9.824054 EV
          HOMO LUMO ENERGIES (EV) =         -9.824  0.236
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        119.70 SQUARE ANGSTROMS
          COSMO VOLUME            =        108.36 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    12    H     9     4.96377
            H    11    H     7     4.29870
            C     4    C     5     0.00000
          SCF CALCULATIONS        =         19
          WALL-CLOCK TIME         =          0.062 SECONDS
          COMPUTATION TIME        =          0.187 SECONDS


          FINAL GEOMETRY OBTAINED
 T=99D PM7 GNORM=0
 Geometry optimization

  C     1.39400383 +1  -0.00000328 +1  -0.00000016 +1
  C     0.69697312 +1   1.20722029 +1   0.00000014 +1
  C    -0.69701677 +1   1.20725994 +1  -0.00000013 +1
  C    -1.39394881 +1   0.00002635 +1   0.00000015 +1
  C    -0.69700022 +1  -1.20724774 +1  -0.00000017 +1
  C     0.69701584 +1  -1.20723648 +1   0.00000017 +1
  H     2.48186688 +1   0.00001451 +1  -0.00000011 +1
  H     1.24094688 +1   2.14935062 +1   0.00000011 +1
  H    -1.24102243 +1   2.14933064 +1  -0.00000011 +1
  H    -2.48182361 +1   0.00001337 +1   0.00000011 +1
  H    -1.24090505 +1  -2.14934964 +1  -0.00000011 +1
  H     1.24084414 +1  -2.14942536 +1   0.00000011 +1
 
