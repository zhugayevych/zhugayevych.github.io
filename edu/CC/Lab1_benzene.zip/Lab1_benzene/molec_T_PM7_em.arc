

                     SUMMARY OF  PM7 CALCULATION, Site No: 7031

                                                       MOPAC2016 (Version: 20.288W)
                                                       Wed Oct 28 01:04:09 2020
                                                       No. of days remaining = 352

           Empirical Formula: C6 H6  =    12 atoms

 PM7 UHF TRIPLET GNORM=0
 To get correctly oriented molecule we slightly expanded C2-C3 and C5-C6 bonds



     GEOMETRY OPTIMISED USING EIGENVECTOR FOLLOWING (EF).     
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =         76.82978 KCAL/MOL =     321.45578 KJ/MOL
          TOTAL ENERGY            =       -815.22486 EV
          ELECTRONIC ENERGY       =      -3224.68517 EV
          CORE-CORE REPULSION     =       2409.46030 EV
          GRADIENT NORM           =          0.00625 = 0.00180 PER ATOM
          DIPOLE                  =          0.00007 DEBYE    POINT GROUP:       D2h 
          (SZ)                    =          1.000000
          (S**2)                  =          2.201897
          NO. OF ALPHA ELECTRONS  =         16
          NO. OF BETA  ELECTRONS  =         14
          IONIZATION POTENTIAL    =          7.393329 EV
          ALPHA SOMO LUMO (EV)    =         -7.393  0.656
          BETA  SOMO LUMO (EV)    =        -10.311 -2.048
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        119.88 SQUARE ANGSTROMS
          COSMO VOLUME            =        108.45 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    10    H     7     5.03686
            H    12    H     9     4.31569
            H    11    H     8     0.00004
          SCF CALCULATIONS        =         26
          WALL-CLOCK TIME         =          0.069 SECONDS
          COMPUTATION TIME        =          0.281 SECONDS


          FINAL GEOMETRY OBTAINED
 PM7 UHF TRIPLET GNORM=0
 To get correctly oriented molecule we slightly expanded C2-C3 and C5-C6 bonds

  C     1.42791441 +1  -0.00007285 +1  -0.00000171 +1
  C     0.74077656 +1   1.20338574 +1   0.00000251 +1
  C    -0.74089955 +1   1.20342122 +1  -0.00000374 +1
  C    -1.42785381 +1   0.00009246 +1   0.00000388 +1
  C    -0.74081491 +1  -1.20341709 +1  -0.00000013 +1
  C     0.74090318 +1  -1.20339008 +1  -0.00000111 +1
  H     2.51845094 +1   0.00002672 +1  -0.00000289 +1
  H     1.24434628 +1   2.15776845 +1   0.00000689 +1
  H    -1.24444205 +1   2.15779756 +1  -0.00000868 +1
  H    -2.51840426 +1   0.00001313 +1   0.00000752 +1
  H    -1.24428768 +1  -2.15778452 +1  -0.00000930 +1
  H     1.24424748 +1  -2.15788829 +1   0.00000751 +1
 
