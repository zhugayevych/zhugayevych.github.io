

                     SUMMARY OF  PM7 CALCULATION, Site No: 7031

                                                       MOPAC2016 (Version: 18.270W)
                                                       Wed Oct 31 22:59:08 2018
                                                       No. of days remaining = 331

           Empirical Formula: C6 H6  =    12 atoms

 PM7 GRAPHF TRIPLET OPEN(4,4)




     GEOMETRY OPTIMISED USING EIGENVECTOR FOLLOWING (EF).     
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =         82.05001 KCAL/MOL =     343.29722 KJ/MOL
          TOTAL ENERGY            =       -814.99864 EV  STATE:   1 TRIPLET B1u 
          ELECTRONIC ENERGY       =      -3228.22330 EV
          CORE-CORE REPULSION     =       2413.22466 EV
          GRADIENT NORM           =          0.67614 = 0.19519 PER ATOM
          DIPOLE                  =          0.00000 DEBYE    POINT GROUP:       D2h 
          NO. OF FILLED LEVELS    =         13
          AND NO. OF OPEN LEVELS  =          4
          CONFIGURATION INTERACTION WAS USED
          IONIZATION POTENTIAL    =          2.394114 EV
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        120.54 SQUARE ANGSTROMS
          COSMO VOLUME            =        108.99 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    12    H     9     5.00851
            H    11    H     8     4.33669
            H    10    C     4     0.00000
          SCF CALCULATIONS        =         16
          WALL-CLOCK TIME         =          0.547 SECONDS
          COMPUTATION TIME        =          2.122 SECONDS


          FINAL GEOMETRY OBTAINED
 PM7 GRAPHF TRIPLET OPEN(4,4)


  C     1.40595775 +1   0.00000000 +1  -0.00000000 +1
  C     0.68088546 +1   1.24420531 +1  -0.00000000 +1
  C    -0.68088546 +1   1.24420531 +1  -0.00000000 +1
  C    -1.40595775 +1   0.00000000 +1  -0.00000000 +1
  C    -0.68088546 +1  -1.24420532 +1  -0.00000000 +1
  C     0.68088546 +1  -1.24420532 +1  -0.00000000 +1
  H     2.48270023 +1   0.00000000 +1   0.00000000 +1
  H     1.25177836 +1   2.16895252 +1   0.00000000 +1
  H    -1.25177836 +1   2.16895252 +1   0.00000000 +1
  H    -2.48270023 +1   0.00000000 +1   0.00000000 +1
  H    -1.25177836 +1  -2.16895252 +1   0.00000000 +1
  H     1.25177836 +1  -2.16895252 +1   0.00000000 +1
 
