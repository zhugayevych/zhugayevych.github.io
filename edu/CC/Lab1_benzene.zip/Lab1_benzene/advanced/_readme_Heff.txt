
TB for pi-system of benzene
 -5.00  -4.34  -0.21  0.69
