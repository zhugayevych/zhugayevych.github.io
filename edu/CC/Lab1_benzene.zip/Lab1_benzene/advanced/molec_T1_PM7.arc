

                     SUMMARY OF  PM7 CALCULATION, Site No: 7031

                                                       MOPAC2016 (Version: 18.270W)
                                                       Wed Oct 31 22:47:01 2018
                                                       No. of days remaining = 331

           Empirical Formula: C6 H6  =    12 atoms

 PM7 GRAPHF UHF TRIPLET




     GEOMETRY OPTIMISED USING EIGENVECTOR FOLLOWING (EF).     
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =         78.18251 KCAL/MOL =     327.11564 KJ/MOL
          TOTAL ENERGY            =       -815.16623 EV
          ELECTRONIC ENERGY       =      -3225.65060 EV
          CORE-CORE REPULSION     =       2410.48437 EV
          GRADIENT NORM           =          0.58770 = 0.16965 PER ATOM
          DIPOLE                  =          0.00045 DEBYE    POINT GROUP:       D2h 
          (SZ)                    =          1.000000
          (S**2)                  =          2.003801
          NO. OF ALPHA ELECTRONS  =         16
          NO. OF BETA  ELECTRONS  =         14
          IONIZATION POTENTIAL    =          7.318159 EV
          ALPHA SOMO LUMO (EV)    =         -7.318  0.577
          BETA  SOMO LUMO (EV)    =        -10.231 -2.133
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        120.61 SQUARE ANGSTROMS
          COSMO VOLUME            =        109.08 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    11    H     8     5.01758
            H    12    H     9     4.34724
            C     3    C     2     0.00000
          SCF CALCULATIONS        =         14
          WALL-CLOCK TIME         =          0.094 SECONDS
          COMPUTATION TIME        =          0.312 SECONDS


          FINAL GEOMETRY OBTAINED
 PM7 GRAPHF UHF TRIPLET


  C     1.40606711 +1   0.00030266 +1  -0.00000015 +1
  C     0.67321409 +1   1.25350821 +1   0.00000020 +1
  C    -0.67305330 +1   1.25379640 +1  -0.00000020 +1
  C    -1.40601656 +1  -0.00014953 +1   0.00000014 +1
  C    -0.67322680 +1  -1.25373969 +1  -0.00000012 +1
  C     0.67303786 +1  -1.25370402 +1   0.00000012 +1
  H     2.48036533 +1   0.00000095 +1  -0.00000002 +1
  H     1.25525654 +1   2.17223732 +1  -0.00000000 +1
  H    -1.25529475 +1   2.17208840 +1   0.00000000 +1
  H    -2.48030235 +1   0.00000003 +1   0.00000002 +1
  H    -1.25523612 +1  -2.17213309 +1   0.00000000 +1
  H     1.25513406 +1  -2.17224205 +1  -0.00000000 +1
 
