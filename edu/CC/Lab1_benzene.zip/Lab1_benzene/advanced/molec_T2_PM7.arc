

                     SUMMARY OF  PM7 CALCULATION, Site No: 7031

                                                       MOPAC2016 (Version: 18.270W)
                                                       Wed Oct 31 22:47:04 2018
                                                       No. of days remaining = 331

           Empirical Formula: C6 H6  =    12 atoms

 PM7 GRAPHF UHF TRIPLET GNORM=0




     GEOMETRY OPTIMISED USING EIGENVECTOR FOLLOWING (EF).     
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =         76.82977 KCAL/MOL =     321.45577 KJ/MOL
          TOTAL ENERGY            =       -815.22486 EV
          ELECTRONIC ENERGY       =      -3224.68492 EV
          CORE-CORE REPULSION     =       2409.46006 EV
          GRADIENT NORM           =          0.00837 = 0.00242 PER ATOM
          DIPOLE                  =          0.00005 DEBYE    POINT GROUP:       D2h 
          (SZ)                    =          1.000000
          (S**2)                  =          2.201908
          NO. OF ALPHA ELECTRONS  =         16
          NO. OF BETA  ELECTRONS  =         14
          IONIZATION POTENTIAL    =          7.393265 EV
          ALPHA SOMO LUMO (EV)    =         -7.393  0.656
          BETA  SOMO LUMO (EV)    =        -10.311 -2.048
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        119.88 SQUARE ANGSTROMS
          COSMO VOLUME            =        108.45 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    11    H     8     5.03687
            H     9    H     7     4.31569
            H    12    H    10     0.00130
          SCF CALCULATIONS        =         73
          WALL-CLOCK TIME         =          0.266 SECONDS
          COMPUTATION TIME        =          0.998 SECONDS


          FINAL GEOMETRY OBTAINED
 PM7 GRAPHF UHF TRIPLET GNORM=0


  C     1.41261074 +1   0.04004394 +1  -0.00013078 +1
  C     0.71374459 +1   1.23669024 +1   0.00007897 +1
  C    -0.67190018 +1   1.24323772 +1   0.00007531 +1
  C    -1.41252915 +1  -0.04001247 +1  -0.00007458 +1
  C    -0.71378861 +1  -1.23671300 +1  -0.00008349 +1
  C     0.67190209 +1  -1.24322449 +1   0.00013300 +1
  H     2.49088579 +1  -0.00096651 +1  -0.00054965 +1
  H     1.25897390 +1   2.18117998 +1   0.00011967 +1
  H    -1.24692825 +1   2.15632637 +1   0.00010305 +1
  H    -2.49082444 +1   0.00100892 +1  -0.00009695 +1
  H    -1.25896422 +1  -2.18116693 +1  -0.00012518 +1
  H     1.24672091 +1  -2.15645754 +1   0.00055447 +1
 
