C:/Sci/tinker/bin/dynamic new 10000 1.0 0.1 2 300>new.out
