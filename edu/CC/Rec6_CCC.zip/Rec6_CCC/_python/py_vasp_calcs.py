from MolMod.SSHTools import *
import os
import numpy as np
import matplotlib.pyplot as plt

def plot_EoS(voldir = '.'):
    #  fit E-vs-VOL points by parabolic equation and plots the data
    #  voldir = string, path to the folder that contains sub folders '1', '2', '3', '4', '5' (each contains 'OUTCAR')
    #  returns volume (A^3) and energy (eV) of the minimum
    vol_folderpath = os.path.abspath(voldir)
    tag_vol = 'volume of cell :'  # 15
    tag_len_vol = len(tag_vol)
    tag_eng = 'energy(sigma->0) ='  # 18
    tag_len_eng = len(tag_eng)
    x = np.empty([5])
    y = np.empty([5])

    for i in range(1,6):
        outcar_path = os.path.join(vol_folderpath, str(i),'OUTCAR')
        outcar = open(outcar_path, "rt")
        for line in outcar:
            if line.find(tag_vol) >= 0:
                x[i-1] = float(line[(line.find(tag_vol) + tag_len_vol):])
            elif line.find(tag_eng) >= 0:
                y[i-1] = float(line[(line.find(tag_eng) + tag_len_eng):])
        outcar.close()

    xp = np.linspace(x.min(),x.max(),40)
    p_coef = np.polyfit(x,y,2)
    p = np.poly1d(p_coef)
    plt.plot(x,y,'.',xp,p(xp),'-')

    x_ex = -p_coef[1]/p_coef[0]/2;
    y_ex = p(x_ex)
    return [x_ex.tolist(), y_ex.tolist()]

class vasp_calc:

    loc_folderpath = os.path.abspath(os.curdir)
    clust_workdir = './vasp_calcs'
    ssh = ''

    def setup(self, loc_folderpath = '.\\', clust_workdir = './vasp_calcs'):

        loc_folderpath = os.path.abspath(loc_folderpath)

        self.loc_folderpath = loc_folderpath
        self.foldername = os.path.split(loc_folderpath)[1]
        self.clust_workdir = clust_workdir


    def upload_folder(self):

        src_files = os.listdir(self.loc_folderpath)
        for item in src_files:
            full_src_name = os.path.join(self.loc_folderpath, item)
            # print(full_src_name)
            dest_name = self.clust_workdir + '/' + self.foldername + '/' + item
            # print(dest_name)
            self.ssh.run('mkdir ' + self.clust_workdir + '/' + self.foldername + ' -p')
            self.ssh.put(full_src_name, dest_name)

    def download_folder(self):

        clust_files = self.ssh.run('ls ' + self.clust_workdir + '/' + self.foldername)
        clust_files = clust_files.split('\n')

        for item in clust_files:
            full_src_name = self.clust_workdir + '/' + self.foldername + '/' + item
            # print(full_src_name)
            dest_name = os.path.join(self.loc_folderpath, item)
            # print(dest_name)
            self.ssh.get(full_src_name, dest_name)

    def submit_job(self):

        # script_name = 'run_vasp'
        # script_file = os.path.join(self.loc_folderpath, script_name)
        # run_script = open(script_file, 'w', newline='\n')
        #
        # print('#!/bin/bash',file = run_script)
        # print('#SBATCH -N 1\n#SBATCH -n 16', file=run_script)
        # print('#SBATCH -J '+self.foldername, file=run_script)
        # print('module add prun/1.0; module add intel/16.0.2.181; module add impi/5.1.3.181', file=run_script)
        # print('cd '+self.clust_workdir+'/'+self.foldername, file=run_script)
        # print('prun /opt/vasp/bin/vasp5.4.4MPI_sol_heap >'+self.foldername+'.log', file=run_script)
        # run_script.close()
        #
        self.upload_folder()
        # self.ssh.run('chmod a+x '+self.clust_workdir + '/' + self.foldername + '/' + script_name)
        # self.ssh.run('sbatch -p AMG '+self.clust_workdir+'/'+self.foldername+'/'+script_name)

        self.ssh.run('cd ' + self.clust_workdir + '/' + self.foldername)
        self.ssh.run('vasp std>out')






