from vasp_calcs import *

vc = vasp_calc()
vc.ssh = SSHTools()
vc.ssh.setup(user="user_name",host="10.17.11.165",pkey="C:/Skol_ssh.ppk")
vc.setup(loc_folderpath = '.\\vasp-calcs\\Si.em\\', clust_workdir = '/home/user_student/vasp_calcs')

vc.submit_job()
vc.download_folder()

# plot_EoS('.\\Si.vol-scan')