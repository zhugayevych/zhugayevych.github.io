import os
import numpy as np
import matplotlib.pyplot as plt
import shutil

def gen_vscan_input(inpdir = '.', n_imag = 5, vol_chng_low  = -10, vol_chng_high = 10):

    inp_folderpath = os.path.abspath(inpdir)
    poscar_path = os.path.join(inp_folderpath, 'POSCAR')
    poscar = open(poscar_path, "rt")
    lines = poscar.readlines()
    scale = float(lines[1])
    vol = np.power(scale,3)
    poscar.close()
    scales = scale*np.cbrt(np.linspace(1-vol_chng_low/100, 1-vol_chng_high/100, num = n_imag))

    for i in range(1,n_imag+1):

        dist = os.path.join(os.path.dirname(inp_folderpath), str(i))
        os.makedirs(dist, exist_ok = True)
        for item in os.listdir(inp_folderpath):
            s = os.path.join(inp_folderpath, item)
            d = os.path.join(dist, item)
            # copy only files, not folders
            if not os.path.isdir(s):
                shutil.copy2(s,d)
        poscar_img_path = os.path.join(dist, 'POSCAR')
        lines[1] = str(scales[i-1])+'\n'
        poscar_img = open(poscar_img_path, 'w', newline='\n')
        poscar_img.writelines(lines)
        poscar_img.close()

def fit_EoS(voldir = '.', n_imag = 5):
    #  fit E-vs-VOL points by parabolic equation and plots the data
    #  voldir = string, path to the folder that contains sub folders '1', '2', '3', '4', '5' (each contains 'OUTCAR')
    #  returns volume (A^3) and energy (eV) of the minimum
    vol_folderpath = os.path.abspath(voldir)
    tag_vol = 'volume of cell :'  # 15
    tag_len_vol = len(tag_vol)
    tag_eng = 'energy(sigma->0) ='  # 18
    tag_len_eng = len(tag_eng)
    x = np.empty([n_imag])
    y = np.empty([n_imag])

    for i in range(1,n_imag+1):
        outcar_path = os.path.join(vol_folderpath, str(i),'OUTCAR')
        outcar = open(outcar_path, "rt")
        for line in outcar:
            if line.find(tag_vol) >= 0:
                x[i-1] = float(line[(line.find(tag_vol) + tag_len_vol):])
            elif line.find(tag_eng) >= 0:
                y[i-1] = float(line[(line.find(tag_eng) + tag_len_eng):])
        outcar.close()

    xp = np.linspace(x.min(),x.max(),40)
    p_coef = np.polyfit(x,y,2)
    p = np.poly1d(p_coef)
    plt.plot(x,y,'.',xp,p(xp),'-')
    plt.xlabel('Volume, A^3')
    plt.ylabel('Energy, eV')

    x_ex = -p_coef[1]/p_coef[0]/2
    y_ex = p(x_ex)
    return [x_ex.tolist(), y_ex.tolist()]


