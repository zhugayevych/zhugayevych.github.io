Calculations are performed by Olga Mazaleva

mpirun -np 6  <executable with full path> -ex <path to folder with .ex files> -t ./tmp_example -b example.bas -i example.in -o example.out &

To run using my batch file, rename basis set file to basis.lib and double-click on fly-file.

