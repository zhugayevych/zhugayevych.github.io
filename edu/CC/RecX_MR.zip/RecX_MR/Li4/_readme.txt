

molec4-s_CAS44c3:  NOocc=(1.957,1,1,0.043)
  E1=-29.74702795, psi=.99(1ab0)-.15(0ab1)
molec4-s_CAS44c3_exc23:  NOocc=(1.852,1.058,1.058,0.032)
  E2=-29.72726964, psi=.70(1100-1010)+.10(0011-0101)
  E3=-29.72287570, psi=.68(1100+1010)-.08(0011-0101)-.25(0110)-.07(1001)
molec4-s_CAS44c3_excT12:  NOocc=(1,1,1,1)
  E1=-29.75316410, psi=.70(1aa0-1a0a)-.10(0a1a+0aa1)
  E2=-29.72930262, psi=(baaa-abaa+aaba-aaab)


molec4-s_PM7o44:

    1   -12.099964    0.000000     1   SINGLET     B1g   010  bond wave
    2   -11.748379    0.351585     1   TRIPLET     A2g   101  triplet
    3   -11.312567    0.787398     1   SINGLET     A1g   000
    4   -10.954165    1.145799     1   TRIPLET     Eu    11/2 spin wave
    6    -9.766441    2.333524     1   SINGLET     B2g   011  site wave
    7    -9.175827    2.924137     1   QUINTET     B1g   210  quintet
    8    -8.372785    3.727179     1   SINGLET     Eu    01/2            1.0703 1.0703 0.0000
   10    -7.891235    4.208729     2   SINGLET     A1g   000  excited

molec4-t_PM7o44:

    1   -11.789064    0.000000     1   SINGLET     E
    3   -11.486897    0.302166     1   TRIPLET     T1
    6    -9.206916    2.582148     1   SINGLET     T2        0.8697      1.3297      0.3228
    9    -9.175736    2.613327     1   QUINTET     A2
   10    -8.247510    3.541554     1   SINGLET     A1
   11    -6.896027    4.893036     2   TRIPLET     T1
