compute in VASP and by CASSCF
