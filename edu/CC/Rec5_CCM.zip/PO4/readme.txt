PO4 in water
                      LiFePO4                FePO4
                     more sym.             less sym.
                       Q=-3                  Q=-1

                        pos   IR Raman      pos   IR  Raman
asym. stretch  T2      1013  453  2.8   2x 1038   5.4  53
                                            976   6.7  47
 sym. stretch  A        876   0   28        915    0   70
asym. bend     T2       543   44  6.8       422   22   11
                                        2x  210   4.8  12
 sym. bend     E        391   0   3.2       267    0   12
                                            238    0   25
