#!/bin/bash
# Standard output and error:
#SBATCH -o ./examplejob.out.%j
#SBATCH -e ./examplejob.err.%j
#SBATCH -D ./
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=32
#SBATCH -J 62-100
#SBATCH --mail-type=none
#SBATCH --partition=p.24h
#SBATCH --time=24:00:00

module load impi intel mkl
# aims_x=/u/hanzhong/bin/aims.160328_3.scalapack.mpi.x
srun SISSO.2.3
