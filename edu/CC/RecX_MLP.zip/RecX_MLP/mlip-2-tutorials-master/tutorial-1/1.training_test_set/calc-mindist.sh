#!/bin/bash

echo Training set mindist:
../mlp mindist train.cfg
