

                     SUMMARY OF PM7 CALCULATION, Site No: 7031

                                                       MOPAC2016 (Version: 17.279W)
                                                       Mon Nov 06 13:45:21 2017
                                                       No. of days remaining = 334

           Empirical Formula: C6 H6  =    12 atoms

 T=99D PM7 GNORM=0
 Geometry optimization



     GEOMETRY OPTIMISED USING EIGENVECTOR FOLLOWING (EF).     
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =         22.95651 KCAL/MOL =      96.05002 KJ/MOL
          TOTAL ENERGY            =       -817.56195 EV
          ELECTRONIC ENERGY       =      -3251.15872 EV
          CORE-CORE REPULSION     =       2433.59677 EV
          GRADIENT NORM           =          0.00975
          DIPOLE                  =          0.00002 DEBYE    POINT GROUP:       D6h 
          NO. OF FILLED LEVELS    =         15
          IONIZATION POTENTIAL    =          9.824055 EV
          HOMO LUMO ENERGIES (EV) =         -9.824  0.236
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        119.70 SQUARE ANGSTROMS
          COSMO VOLUME            =        108.36 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    12    H     9     4.96376
            H    10    H     7     4.29871
            C     6    C     1     0.00001
          SCF CALCULATIONS        =         17
          WALL-CLOCK TIME         =          0.227 SECONDS
          COMPUTATION TIME        =          0.671 SECONDS


          FINAL GEOMETRY OBTAINED
 T=99D PM7 GNORM=0
 Geometry optimization

  C     1.39400612 +1  -0.00000302 +1  -0.00000233 +1
  C     0.69697335 +1   1.20721727 +1   0.00000230 +1
  C    -0.69701700 +1   1.20725781 +1  -0.00000228 +1
  C    -1.39395258 +1   0.00002654 +1   0.00000229 +1
  C    -0.69699990 +1  -1.20724650 +1  -0.00000231 +1
  C     0.69701532 +1  -1.20723408 +1   0.00000233 +1
  H     2.48187354 +1   0.00001397 +1   0.00000034 +1
  H     1.24093436 +1   2.14935277 +1  -0.00000033 +1
  H    -1.24100679 +1   2.14933414 +1   0.00000033 +1
  H    -2.48183119 +1   0.00001366 +1  -0.00000033 +1
  H    -1.24089576 +1  -2.14935153 +1   0.00000034 +1
  H     1.24083846 +1  -2.14942519 +1  -0.00000034 +1
 
