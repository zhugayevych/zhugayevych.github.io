HOMO and LUMO symmetries are e1g and e2u respectively.

e1g x e2u = b1u + b2u + e1u  (see http://www.cryst.ehu.es/cgi-bin/rep/programs/sam/point.py?sg=191&num=27)

Therefore observed excitations are HOMO->LUMO transitions.

V = e1u + a2u

Therefore only E1u transition is dipole-allowed with the transition dipole lying in the molecular plane.

B3LYP/6-31g* calculations give 5.54, 6.31, and 7.38 with oscillator strength 2*0.5586=1.12 in satisfactory agreement with experiment.
