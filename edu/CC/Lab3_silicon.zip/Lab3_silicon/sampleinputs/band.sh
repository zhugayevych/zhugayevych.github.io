#!/bin/bash


vasp_std="vasp_std"

./sp.sh

cp INCAR_band INCAR
cp CONTCAR_em POSCAR
cp KPOINTS_band KPOINTS

$vasp_std

cp OUTCAR OUTCAR_band
cp EIGENVAL EIGENVAL_band
cp vasprun.xml vasprun_band.xml