#!/bin/bash


vasp_std="vasp_std"


cp INCAR_bader INCAR
cp CONTCAR_em POSCAR
cp KPOINTS KPOINTS

$vasp_std

./chgsum.pl AECCAR0 AECCAR2

./bader CHGCAR -ref CHGCAR_sum

cp OUTCAR OUTCAR_bader
