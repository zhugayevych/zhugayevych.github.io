#!/bin/bash


vasp_std="vasp_std"


cp INCAR_freq INCAR
cp CONTCAR_em POSCAR
cp KPOINTS_dos KPOINTS

$vasp_std

cp OUTCAR OUTCAR_freq
cp vasprun.xml vasprun_freq.xml