rm -f CHG CONTCAR DOSCAR DYNMAT EIGENVAL IBZKPT OPTIC OSZICAR* OUTCAR PROCAR* \
      PCDAT W* XDATCAR PARCHG* vasprun.xml SUMMARY.* REPORT \
      wannier90.win wannier90_band.gnu wannier90_band.kpt wannier90.chk wannier90.wout \
      *.dat plotfile p4vasp.log \
      *.e[0-9]* *.o[0-9]* *.pe[0-9]* *.po[0-9]* *.err *.out 
