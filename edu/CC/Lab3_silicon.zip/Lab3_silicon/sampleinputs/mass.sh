#!/bin/bash


vasp_std="vasp_std"

./sp.sh

cp INCAR_band INCAR
cp POSCAR_mass POSCAR
cp KPOINTS_mass KPOINTS

$vasp_std

cp OUTCAR OUTCAR_mass
cp EIGENVAL EIGENVAL_mass
cp vasprun.xml vasprun_mass.xml