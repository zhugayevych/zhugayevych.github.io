#!/bin/bash


vasp_std="vasp_std"


cp INCAR_em INCAR
cp POSCAR_em POSCAR
cp KPOINTS_em KPOINTS

$vasp_std

cp OUTCAR OUTCAR_em
cp CONTCAR CONTCAR_em