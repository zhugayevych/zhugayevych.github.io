#!/bin/bash


vasp_std="vasp_std"


cp INCAR_elastic INCAR
cp CONTCAR_em POSCAR
cp KPOINTS_em KPOINTS

$vasp_std

cp OUTCAR OUTCAR_elastic
cp vasprun.xml vasprun_elastic.xml