#!/bin/bash


vasp_std="vasp_std"


cp INCAR_eos INCAR
cp KPOINTS_em KPOINTS

for i in  0 1 2 3 4 5 6 ; do
cp POSCAR_eos$i POSCAR
$vasp_std
cp OUTCAR OUTCAR_eos$i
cp CONTCAR CONTCAR_eos$i
done