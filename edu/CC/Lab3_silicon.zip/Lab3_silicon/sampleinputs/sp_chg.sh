#!/bin/bash


vasp_std="vasp_std"


cp INCAR_sp INCAR
cp POSCAR_sc POSCAR
cp KPOINTS_sc KPOINTS

$vasp_std

cp OUTCAR OUTCAR_sc
cp CHGCAR CHGCAR_sc
