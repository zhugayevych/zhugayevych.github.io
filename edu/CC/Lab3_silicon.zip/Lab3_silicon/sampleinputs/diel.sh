#!/bin/bash


vasp_std="vasp_std"

./sp2.sh

cp INCAR_LOPTICS INCAR
cp CONTCAR_em POSCAR
cp KPOINTS_em KPOINTS

$vasp_std

cp OUTCAR OUTCAR_LOPTICS
cp vasprun.xml vasprun_LOPTICS.xml
#cp WAVECAR WAVECAR_LOPTICS
#cp WAVEDER WAVEDER_LOPTICS
./plotoptics.sh

