#!/bin/bash


vasp_std="vasp_std"


cp INCAR_dos INCAR
cp CONTCAR_em POSCAR
cp KPOINTS_dos KPOINTS

$vasp_std

cp OUTCAR OUTCAR_dos
cp DOSCAR DOSCAR_dos
cp vasprun.xml vasprun_dos.xml
