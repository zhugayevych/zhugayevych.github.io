#!/bin/bash


vasp_std="vasp_std"


cp INCAR_sp2 INCAR
cp CONTCAR_em POSCAR
cp KPOINTS_em KPOINTS

$vasp_std

cp OUTCAR OUTCAR_sp2
cp vasprun.xml vasprun_sp2.xml