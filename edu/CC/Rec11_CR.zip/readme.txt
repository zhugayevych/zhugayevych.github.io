[HWrules] Make reaction-runs faster and provide output for long runs. More detailed comments are needed. In particular electronic structure at TS.
