The article can be downloaded here:
 http://zhugayevych.me/pub/Klimovich21.pdf
 http://zhugayevych.me/pub/Klimovich21add.pdf
