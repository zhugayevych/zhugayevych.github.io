

Conformers:

 conformer        E(meV)
        CAM-B3LYPp2p  CAM-B3LYP-D3p2p
 molec-a       0           0
 molec-b       0.020       -
 molec-sa     16.98       16.28
 molec-sb     74.61       77.84



Energies (in eV) for molec-a_CAM-B3LYPp2p:

 IP=7.37   IP+HOMO=+0.19
 EA=2.62   EA+LUMO=-0.33
 S1=2.39   osc.str.=1.11
 T0=1.77



Binding energy (in eV per BF3, CAM-B3LYPp2p):
 0.36  relaxed   (BSSE-corrected)
 1.35  unrelaxed (BSSE-corrected)
 0.30  BSSE
