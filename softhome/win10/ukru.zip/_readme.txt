1) Run ukru/setup.exe (Keyboard Layout Creator Bootstrap).
 .NET Framework 2.0 is required to install this keyboard layout.
 You can install .NET Framework 3.5 which includes .NET 2.0 and 3.0.

2) Also you can generate the installer from ukru.klc file using
 Microsoft Keyboard Layout Creator 1.4 (it needs .NET Framework 2.0).
